#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "constants.h"
#include "diskfunc.h"

//Check the root entries for the file name of interest
void findFile(FILE *file, char *inName, int **re){ 
    int index = NUM_SECTORS_START*SECTOR_SIZE;
    char *name = malloc(sizeof(char)*1000);
    unsigned char attr;
    int fsize = 0;
    int fclust,i;
    int pclust = -1;
    for(i=(NUM_SECTORS_START*SECTOR_SIZE);i<(33*SECTOR_SIZE);i+=32){
        attr = getByteAt(file,i+11);
        //If the attribute is incorrect for a file skip it
        if(getByteAt(file,i) == 0xE5|| attr == 0x0F || attr  & 0x08) continue;
        //otherwise get the file name
        name = getFileName(file,i,&name);
        if(strlen(name)>0 && !strcmp(name,inName)){
            fsize = getFileSize(file,i+28); 
            fclust = getByteAt(file,i+26); 
            pclust = 33+fclust-2;
            break;
        }
    }
    //re holds both the cluster and the file size to be returned`
    *(*re) = pclust;
    *((*re)+1) = fsize;
}


int main(int argc, char *argv[]) {
    if(argc != 3) {
        printf("USAGE: diskget <.IMG file> <filename>\n");
        exit(0);
    }
    //open the disk image file
    FILE *file = fopen(argv[1], "r+");
    if(file == NULL) {
        printf("Could not open file\n");
        exit(0);
    }
    int* re = malloc(sizeof(int)*2);

    char *fname = malloc(sizeof(char)*strlen(argv[2]));
    int i;
    for(i=0;i<strlen(argv[2]);i++){
       *(fname+i) = toupper(*(argv[2]+i)); 
    }

    findFile(file,fname,&re);
    int pclust = re[0];
    int fsize = re[1];
    if(pclust == -1){
        printf("File not found.\n");
        exit(0);
    }
    //goto the start of the located file
    int offset = pclust*SECTOR_SIZE;
    unsigned char currChar;
    fseek(file,offset,SEEK_SET);
    FILE *writeFile = fopen(argv[2],"w");
    if(writeFile==NULL){
        printf("Error opening file\n");
        exit(0);
    }
    //copy the characters 1 by 1
    for(i = 0; i<fsize; i++){
       currChar = fgetc(file); 
       fputc(currChar,writeFile);
    }
        
    fclose(file);
    fclose(writeFile);
    free(fname);
    free(re);
    exit(0);
}
