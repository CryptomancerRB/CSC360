#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "constants.h"
#include "diskfunc.h"



int main(int argc, char *argv[]) {
    if(argc != 2) {
        printf("Incorrect usage of diskinfo\nEX: ./disklist <disk-image>\n");
        exit(0);
    }
    //open the disk image file
    FILE *file = fopen(argv[1], "r+");
    if(file == NULL) {
        fprintf(stderr, "Could not open file\n");
        exit(1);
    }
    char *osName = getOS(file);
    printf("OS Name: %s\n", osName);
    char *volLab = getVolLab(file);
    //if volume label is not in boot sector, retrieve it from the root directory
    if(strspn(volLab, " \n\r\t") == strlen(volLab)) {
        char *rootLab = getRootLab(file);
        printf("Label of the disk: %s\n", rootLab);
        free(rootLab);
    } else {
        printf("Label of the disk: %s\n", volLab);
    }
    int diskSize = getSize(file);
    printf("Total size of the disk: %d\n", diskSize);
    int freeSize = getFreeSize(file, diskSize);
    printf("Free size of the disk: %d\n", freeSize);
    printf("\n==============\n");
    printf("Number of files in the root directory (not including subdirectories): %d\n", getRootNumFiles(file));
    printf("\n==============\n");
    printf("Number of FAT copies: %d\n", getFatNumCopy(file));
    printf("Sectors per FAT: %d\n", secPerFat(file));
    printf("\n");
    fclose(file);
    free(osName);
    free(volLab);
    exit(0);
}
