#include<stdio.h>
#include<constants.h>
#include<stdlib.h>
#include<string.h>

//Function to rerive a number in little endian
int getByteAt(FILE *file, int offset){
    fseek(file, offset, SEEK_SET);
    unsigned char low,hi;
    low = fgetc(file);
    hi = fgetc(file);
    return (hi<<8)+low;
}

//Get a file name includeing extention fron the root sector
char* getFileName(FILE *file, int offset, char **name){
    char currChar;
    //goto the beginning of the file name
    fseek(file, offset, SEEK_SET);
    int endName = 8;
    for(int i = 0; i<8; i++){
        currChar = fgetc(file);
        *((*name)+i) = currChar;
        //On a null...
        if(currChar == 0x00){
            endName = i;
            break;
        }
        //Or a space..,
        else if(currChar == 32){
            endName = i;
            break;
        }
    }
    //goto beginning of the extention..
    fseek(file, offset+8, SEEK_SET);
    for(int i = 1; i<4; i++){
        currChar = fgetc(file);
        *((*name)+i+endName) = currChar;
        //At the end of the extention...
        if(currChar == 0x00){
            //If there's no extention terminate the string
            if(i == 1){
                *((*name)+endName) = '\0';
                break;
            }
            //If there was an extension less than 3 bytes, add the . and null num terminate
            else{
                *((*name)+endName) = '.';
                *((*name)+i+endName) = '\0';
                break;
            }
        }
        //If the extension took up the full three spots do the same
        else if(i == 3){
            *((*name)+endName) = '.';
            *((*name)+i+endName+1) = '\0';
        }
    }
    return *name;

}

//Get the file size with is stored as 2 seperate 2 byte numbers
int getFileSize(FILE *file, int offset){
    int size = 0;
    fseek(file, offset, SEEK_SET);
    size += fgetc(file);
    size += fgetc(file)<<8;
    size += fgetc(file)<<16;
    size += fgetc(file)<<24;
    return size;
}

//Source: lab slides
void getDateTime(FILE *file, int offset, int **reArray){
	
	int time, date;
	int hours, minutes, day, month, year;	
	
	time = getByteAt(file,offset);
	date = getByteAt(file,offset+2);
	
	//the year is stored as a value since 1980
	//the year is stored in the high seven bits
	year = ((date & 0xFE00) >> 9) + 1980;
	//the month is stored in the middle four bits
	month = (date & 0x1E0) >> 5;
	//the day is stored in the low five bits
	day = (date & 0x1F);
	
	printf("%d-%02d-%02d ", year, month, day);
	//the hours are stored in the high five bits
	hours = (time & 0xF800) >> 11;
	//the minutes are stored in the middle 6 bits
	minutes = (time & 0x7E0) >> 5;
	
	printf("%02d:%02d\n", hours, minutes);
	return ;	
}

//Get OS name
char *getOS(FILE *file) {
    char *os = malloc(sizeof(char) * (OS_NAME_LEN + 1));
    fseek(file, OS_NAME_START, SEEK_SET);
    fread(os, sizeof(char), sizeof(char) * OS_NAME_LEN, file);
    //Everything will need to be null terminated 
    os[OS_NAME_LEN] = '\0';
    return os;
}

//Get volume label
char *getVolLab(FILE *file) {
    char *label = malloc(sizeof(char) * (LABEL_LEN + 1));
    fseek(file, LABEL_START, SEEK_SET);
    fread(label, sizeof(char), sizeof(char) * LABEL_LEN, file);
    label[LABEL_LEN] = '\0';
    return label;
}

//Get the directory label on root
char *getRootLab(FILE *file) {
    unsigned char buf[ROOT_ENTRY_LENGTH];
    fseek(file, ROOT_SECTOR * SECTOR_SIZE, SEEK_SET);
    fread(&buf[0], sizeof(unsigned char), sizeof(unsigned char) * ROOT_ENTRY_LENGTH, file);
    int i = ROOT_ENTRY_LENGTH;
    //Find the volume labels only
    while((buf[ATTRIBUTES_START] & 0x08) != 0x08 || buf[ATTRIBUTES_START] == 0x0F) {
        fseek(file, ROOT_SECTOR * SECTOR_SIZE + i, SEEK_SET);
        fread(&buf[0], sizeof(unsigned char), sizeof(unsigned char) * ROOT_ENTRY_LENGTH, file);
        i += ROOT_ENTRY_LENGTH;
        if(buf[0] == 0x00) {
            return 0;
        }
    }
    //retrive volume label
    char *label = malloc(sizeof(char) * (FILE_NAME_LEN + 1));
    int j;
    for(j = 0; j < FILE_NAME_LEN; j++) {
        label[j] = buf[j];
    }
    label[FILE_NAME_LEN] = '\0';
    return label;
}

//Gets the total size of the disk
int getSize(FILE *file) {
    //get bytes per sector
    fseek(file, BYTES_SECTOR_START, SEEK_SET);
    int bytes_per_sec = getByteAt(file, BYTES_SECTOR_START);

    //get number of sectors
    int tot_sec = getByteAt(file, NUM_SECTORS_START);
    return bytes_per_sec * tot_sec;
}

//Get disk free space
int getFreeSize(FILE *file, int size) {
    int i,low_byte,mid_byte,upr_byte,entry;
    int offset = SECTOR_SIZE;
    int totSecs = getByteAt(file, NUM_SECTORS_START);
    int secs = 0;
    int empSecs = 0;
    //Check each FAT entry to see how many are empty
    for(i = offset+3; i < 10*512; i+=3) {
        //i tracks groups of three bytes or 2 entries
        secs+=2;
        if(secs>totSecs-33){
            break;
        }
        fseek(file,i,SEEK_SET);
        low_byte = fgetc(file);
        mid_byte = fgetc(file);
        upr_byte = fgetc(file);
        if((upr_byte<<4)+((mid_byte&0xF0)>>4)==0x00) empSecs++;
        if(((mid_byte&0x0F)<<8)+low_byte==0x00) empSecs++;
    }
    return empSecs * SECTOR_SIZE;
}

/*Gets the number of files the root directory*/
int getRootNumFiles(FILE *file) {
    fseek(file, ROOT_SECTOR * SECTOR_SIZE, SEEK_SET);
    int count = 0;
    int pos = 0;
    unsigned char t;
    unsigned char c = fgetc(file);
    while(c!= 0x00) {
        fseek(file, ROOT_SECTOR * SECTOR_SIZE + pos + ATTRIBUTES_START, SEEK_SET);
        t = fgetc(file);
        //Only count files that don't have a whacky attribute
        if(t != 0x0F && (t & 0x08) == 0 && (t & 0x10) == 0 && (t & 0x40) == 0 && (t & 0x80) == 0) {
            count++;
        }
        pos += ROOT_ENTRY_LENGTH;
        fseek(file, ROOT_SECTOR * SECTOR_SIZE + pos, SEEK_SET);
        c = fgetc(file);
    }
    return count;
}

//Lookup # of FAT copies
int getFatNumCopy(FILE *file) {
    fseek(file, FAT_NUMBER_START, SEEK_SET);
    return fgetc(file);
}

//Lookup # sectors per FAT
int secPerFat(FILE *file) {
    return getByteAt(file, SECTORS_FAT_START);
}
