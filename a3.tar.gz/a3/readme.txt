make all with "make all" or "make"
make an individual executable with "make <name>"

diskget and diskput take filenames of the form <1-8 alphanum chars>.<0-3 alphanum chars>
all inputs will be converted to uppercase

programs can be run as such:
./diskinfo <disk.IMA>
./disklist <disk.IMA>
./diskget <disk.IMA> <filename on disk.IMA>
./diskput <disk.IMA> <relative filepath>
