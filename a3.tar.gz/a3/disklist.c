#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "constants.h"
#include "diskfunc.h"



int main(int argc, char *argv[]) {
    if(argc != 2) {
        printf("USAGE: disklist <.IMG file>\n");
        exit(0);
    }
    //open the disk image file
    FILE *file = fopen(argv[1], "r+");
    if(file == NULL) {
        printf("Could not open file\n");
        exit(0);
    }
    int index = 19*SECTOR_SIZE;
    char *name = malloc(sizeof(char)*1000);
    unsigned char attr;
    int fsize = 0;
    int i;
    //for each file in the root directory...
    for(i=(19*SECTOR_SIZE);i<(33*SECTOR_SIZE);i+=32){
        attr = getByteAt(file,i+11);
        //if its attributes aren't non-file one ones...
        if(getByteAt(file,i) == 0xE5|| attr == 0x0F || attr  & 0x08) continue;
        //Get the name and print out its information
        name = getFileName(file,i,&name);
        if(strlen(name)>0){
            fsize = getFileSize(file,i+28); 
            if(attr & 0x10) printf("D ");
            else printf("F ");
            printf("%10d ",fsize);
            printf("%20s ",name);
            //getDateTime prints in place
            getDateTime(file,i+14);
        }
    }
    //close the file again
    fclose(file);
    exit(0);
}
