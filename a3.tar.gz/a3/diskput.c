#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>
#include "constants.h"
#include "diskfunc.h"


//search the first FAT sector for an empty slot to insert the next entry of our file into
int findEmptySector(FILE *file,int curr){
    int entry;
    int i,lower,middle,upper;
    int FATnum = 2;
    int offset = SECTOR_SIZE;
    //Iterate in chunks of 3 bytes, each of which represent 2 entries
    for(i = offset+3;i<10*offset;i+=3){
        fseek(file,i,SEEK_SET);
        lower = fgetc(file);
        middle = fgetc(file);
        upper = fgetc(file);
        entry = (middle&0x0F)<<8;
        entry+= lower;
        if(FATnum != curr && entry == 0x000){
            return FATnum;
        }
        entry = upper<<4;
        entry += (middle&0xF0)>>4;
        FATnum++;
        if(FATnum != curr && entry == 0x000){
            return FATnum;
        }
        FATnum++;
    }
    printf("No enough free space in the disk image.\n");
    exit(0);
}

//Create a new FAT entry in the correct spot pointing to the next one, or with 0xFFF
void writeFATentry(FILE *file, int FATsec, int sectorEnd){
    int upr,low,half,fat;
    int sectorStart = SECTOR_SIZE;
    int secondFATstart = SECTOR_SIZE*10;
    //Figure out what memory location FATsec (n) is at
    if(FATsec%2==0){
        sectorStart+=(FATsec/2)*3;
        secondFATstart+=(FATsec/2)*3;
        fseek(file,sectorStart+1,SEEK_SET);
        //get the other half of the middle byte so we don't corrupt it
        half = fgetc(file); 
        fseek(file,sectorStart,SEEK_SET);
        fputc(sectorEnd&0x0FF,file);
        fputc(((sectorEnd&0xF00)>>8)+(half&0xF0),file);

        //Add a copy into the duplicate FAT table
        fseek(file,secondFATstart,SEEK_SET);
        fputc(sectorEnd&0x0FF,file);
        fputc(((sectorEnd&0xF00)>>8)+(half&0xF0),file);
    }
    else{
        sectorStart+=(((FATsec-1)/2)*3)+1;
        fseek(file,sectorStart,SEEK_SET);
        //get the other half of the middle byte so we don't corrupt it
        half = fgetc(file);
        fseek(file,sectorStart,SEEK_SET);
        fputc((half&0x0F)+(sectorEnd&0x00F)<<4,file);
        fputc((sectorEnd&0xFF0)>>4,file);
        
        //Add a copy into the duplicate FAT table
        fseek(file,secondFATstart,SEEK_SET);
        fputc((half&0x0F)+(sectorEnd&0x00F)<<4,file);
        fputc((sectorEnd&0xFF0)>>4,file);
    }
}

//Get the time and put it into the proper format
//Source https://www.viathinksoft.de/svn/autosfx/zmstr1900102/DLL/dz1900087src/Source/Common.cpp
int createTime(){
    time_t currTime;
    struct tm * timeinfo;

    time (&currTime);
    timeinfo = localtime (&currTime);
    int h = timeinfo->tm_hour;
    int m = timeinfo->tm_min;
    int s = timeinfo->tm_sec;
    int time = ((h & 0x1f) << 11) | ((m & 0x3f) << 5) | (s & 0x1f);
    return time;
}

//Get date and put it into proper format
int createDate(){
	time_t currTime;
  	struct tm * timeinfo;
  	time (&currTime);
  	timeinfo = localtime (&currTime);
	//Linux starts at 1900 FAT starts at 1980
  	int y = timeinfo->tm_year - 80; 
  	int m = timeinfo->tm_mon + 1;
  	int d = timeinfo->tm_mday;
  	int date = ((y & 0x7f) << 9) | ((m & 0xf) << 5) | (d & 0x1f);
	return date;  
}

//Write a 2 byte number in the proper little endian format
void writeNum(FILE *file, int num, int offset){
    unsigned int mask = 0x00FF;
    unsigned char n;
    fseek(file,offset, SEEK_SET);
    n = num & (mask);
    fputc(n,file);
    n = (num & (mask<<8))>>8;
    fputc(n,file);
    return;
}

//Create a new entry for the added file in the root sector
void createRootEntry(FILE *file, char *fname, int fsize, int clustLoc){ 
    int index = NUM_SECTORS_START*SECTOR_SIZE;
    unsigned char attr;
    int fclust;
    int pclust = -1;
    int endName = strlen(fname);
    int inName = 1;
    int offset,i;
    int ext = 0;
    int l = strlen(fname);
    //Assignment says not to worry about long names
    if(l>12){
        printf("ERROR: Name too long.\n");
        exit(0);
    }
    unsigned char curr;
    //find an empty spot
    for(i=(NUM_SECTORS_START*SECTOR_SIZE);i<(33*SECTOR_SIZE);i+=32){
        curr = getByteAt(file,i);
        if(curr == 0xE5 || curr == 0x00){
            offset = i;
            break;
        }
    }
    //fill in attr field
    fseek(file,offset+11, SEEK_SET);
    fputc(0x00, file);
    fseek(file,offset, SEEK_SET);
    int j;
    //coppy in the name with the proper spacing
    for(j=0;j<8;j++){
        if(j>=endName){
            inName = 0;
        }
        if(inName && *(fname+j) == '.'){
            ext = 1;
            inName = 0;
            endName = j+1;
        }
        if(inName){
            fputc(*(fname+j),file);
        }
        else{
            fputc(0x00,file);
        }
    }
    //confirm that an 11 digit name can't slip in without using part for an extension
    if(*(fname+endName-1)!='.'){
        printf("ERROR: Name too long.\n");
        exit(0);
    }
    for(j=endName;j<endName+3;j++){
        if(ext && j<l){
            fputc(*(fname+j),file);
        }
        else{
            fputc(0x00,file);
        }
    }
    writeNum(file,clustLoc,offset+26);

    //Copy in the time and date
    unsigned int mask = 0x0000FFFF;
    writeNum(file,fsize&mask,offset+28);      
    writeNum(file,(fsize>>16)&mask,offset+30);

    int date = createDate();
    writeNum(file,date,offset+16);
    writeNum(file,date,offset+18);
    writeNum(file,date,offset+24);
    int time = createTime();
    writeNum(file,time,offset+14);
    writeNum(file,time,offset+22);
}

int main(int argc, char *argv[]) {
    if(argc != 3) {
        printf("USAGE: diskget <.IMG file> <filename>\n");
        exit(0);
    }
    //open the disk image file
    FILE *file = fopen(argv[1], "r+");
    if(file == NULL) {
        fprintf(stderr, "Could not open file\n");
        exit(1);
    }
    //open the file to be copied
    FILE *readFile = fopen(argv[2],"r");
    if(readFile==NULL){
        printf("File not found.\n");
        exit(0);
    }
    char *fname = malloc(sizeof(char)*strlen(argv[2]));
    //Convert all inputs arg to uppercase
    int i;
    for(i=0;i<strlen(argv[2]);i++){
       *(fname+i) = toupper(*(argv[2]+i)); 
    }
    fseek(readFile, 0, SEEK_END);
    int fsize = ftell(readFile);
    fseek(readFile,0, SEEK_SET);
    //Make sure there's enough room for out new file
    int freeSize = getFreeSize(file,getSize(file));
    if(freeSize < fsize){
        printf("No enough free space in the disk image.");
        exit(0);
    }
    int numBlocks = ceil((double)fsize/(double)SECTOR_SIZE);
    int remainder = fsize;
    int curr = findEmptySector(file,0);
    int charsForCopy,next,f,j;
    char currChar;
    //Add the file to the root directory
    createRootEntry(file,fname,fsize,curr);
    for(i = 0; i < numBlocks; i++){ 
        charsForCopy = ((remainder<SECTOR_SIZE)?remainder:SECTOR_SIZE);
        //Copy characters in
        fseek(file,((curr+31)*SECTOR_SIZE),SEEK_SET);
        for(j = 0; j < charsForCopy; j++){
            currChar = fgetc(readFile); 
            fputc(currChar,file);
        }

        //Update the FAT
        if(remainder<SECTOR_SIZE){
            writeFATentry(file,curr,0xFFF);
        }
        else{
            next = findEmptySector(file,curr);
            writeFATentry(file,curr,next);
            curr = next;
        }
        remainder-=charsForCopy;
    }
    exit(0);

    fclose(file);
    fclose(readFile);
    free(fname);
    exit(0);
}
