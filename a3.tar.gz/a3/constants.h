/*
 * Constants used in assignment 3
 */

#define OS_NAME_START 3
#define OS_NAME_LEN 8
#define NUM_SECTORS_START 19
#define BYTES_SECTOR_START 11
#define LABEL_START 43
#define LABEL_LEN 11
#define SECTOR_SIZE 512
#define ROOT_SECTOR 19
#define ROOT_ENTRY_LENGTH 32
#define ATTRIBUTES_START 11
#define FILE_NAME_LEN 8
#define FAT_SECTOR_START 1
#define FAT_SECTOR_END 10
#define FAT_NUMBER_START 16
#define SECTORS_FAT_START 22
#define SECTORS_FAT_LEN 2
#define FILE_SIZE_START 28
#define FILE_SIZE_LEN 4
#define timeOffset 14 //offset of creation time in directory entry
#define dateOffset 16 //offset of creation date in directory entry
